#pragma once
#include <atomic>
#include <cstdint>
#include <vector>

namespace NXR::Render {
    class AudioTap {
    public:
        static AudioTap& get();

        int probeSampleRate();
        bool attach(int offsetMs);
        void detach();
        void setGate(bool open);
        void collect(int64_t targetUs, std::vector<float>& out);
        void feed(const float* input, unsigned frames, int channels);

    private:
        AudioTap() = default;

        void resetCounters(int offsetMs);

        static constexpr size_t kRingFrames = size_t(1) << 18;

        void* m_dsp = nullptr;
        int m_rate = 48000;
        std::vector<float> m_ring;
        std::atomic<size_t> m_head { 0 };
        std::atomic<size_t> m_tail { 0 };
        std::atomic<bool> m_gate { false };

        uint64_t m_written = 0;
        int64_t m_shiftFrames = 0;
        bool m_shiftApplied = false;
        uint64_t m_discardPending = 0;
    };
}
