#include "nxr_video_sink.hpp"

#ifdef GEODE_IS_ANDROID
#include <media/NdkMediaCodec.h>
#include <media/NdkMediaFormat.h>
#include <media/NdkMediaMuxer.h>
#include <fcntl.h>
#include <unistd.h>
#include <algorithm>
#include <cstring>
#include <dlfcn.h>
#include <thread>

namespace {
    constexpr int32_t kColorFormatSemiPlanar = 21;
    constexpr int32_t kBitrateModeVariable = 1;
    constexpr int64_t kDequeueTimeoutUs = 10000;

    uint8_t clampByte(int value) {
        return static_cast<uint8_t>(std::clamp(value, 0, 255));
    }

    class MediaCodecSink final : public NXR::Render::VideoSink {
    public:
        ~MediaCodecSink() override { close(); }

        geode::Result<> open(const NXR::Render::SinkConfig& config) override {
            m_width = config.width;
            m_height = config.height;
            m_fps = std::max(config.fps, 1);

            m_fileDescriptor = ::open(config.outputPath.c_str(), O_CREAT | O_RDWR | O_TRUNC, 0644);
            if (m_fileDescriptor < 0) return geode::Err("Cannot open the output file");

            m_muxer = AMediaMuxer_new(m_fileDescriptor, AMEDIAMUXER_OUTPUT_FORMAT_MPEG_4);
            if (!m_muxer) return failOpen("Cannot create the MP4 muxer");

            m_codec = AMediaCodec_createEncoderByType("video/avc");
            if (!m_codec) return failOpen("No H.264 hardware encoder on this device");

            AMediaFormat* format = AMediaFormat_new();
            AMediaFormat_setString(format, "mime", "video/avc");
            AMediaFormat_setInt32(format, "width", m_width);
            AMediaFormat_setInt32(format, "height", m_height);
            AMediaFormat_setInt32(format, "bitrate", config.bitrateMbps * 1000000);
            AMediaFormat_setInt32(format, "bitrate-mode", kBitrateModeVariable);
            AMediaFormat_setInt32(format, "frame-rate", m_fps);
            AMediaFormat_setInt32(format, "color-format", kColorFormatSemiPlanar);
            AMediaFormat_setInt32(format, "i-frame-interval", 1);

            const media_status_t configured = AMediaCodec_configure(m_codec, format, nullptr, nullptr, AMEDIACODEC_CONFIGURE_FLAG_ENCODE);
            AMediaFormat_delete(format);
            if (configured != AMEDIA_OK) return failOpen("The encoder rejected this resolution or bitrate");
            if (AMediaCodec_start(m_codec) != AMEDIA_OK) return failOpen("The encoder did not start");

            m_stride = m_width;
            m_sliceHeight = m_height;
            using InputFormatFn = AMediaFormat* (*)(AMediaCodec*);
            static auto inputFormatOf = reinterpret_cast<InputFormatFn>(dlsym(RTLD_DEFAULT, "AMediaCodec_getInputFormat"));
            if (AMediaFormat* input = inputFormatOf ? inputFormatOf(m_codec) : nullptr) {
                int32_t stride = 0;
                int32_t slice = 0;
                if (AMediaFormat_getInt32(input, "stride", &stride) && stride >= m_width) m_stride = stride;
                if (AMediaFormat_getInt32(input, "slice-height", &slice) && slice >= m_height) m_sliceHeight = slice;
                AMediaFormat_delete(input);
            }

            m_yuv.assign(static_cast<size_t>(m_stride) * m_sliceHeight * 3 / 2, 0);
            m_frameIndex = 0;
            return geode::Ok();
        }

        void write(const std::vector<uint8_t>& topDownRgba) override {
            if (!m_codec) return;

            convertToSemiPlanar(topDownRgba);

            for (;;) {
                const ssize_t slot = AMediaCodec_dequeueInputBuffer(m_codec, kDequeueTimeoutUs);
                if (slot >= 0) {
                    size_t capacity = 0;
                    uint8_t* target = AMediaCodec_getInputBuffer(m_codec, static_cast<size_t>(slot), &capacity);
                    const size_t bytes = std::min(capacity, m_yuv.size());
                    if (target) std::memcpy(target, m_yuv.data(), bytes);
                    const int64_t timestampUs = m_frameIndex * 1000000LL / m_fps;
                    AMediaCodec_queueInputBuffer(m_codec, static_cast<size_t>(slot), 0, bytes, static_cast<uint64_t>(timestampUs), 0);
                    ++m_frameIndex;
                    drainEncoded(false);
                    return;
                }
                drainEncoded(false);
            }
        }

        void close() override {
            if (m_codec) {
                signalEndOfStream();
                AMediaCodec_stop(m_codec);
                AMediaCodec_delete(m_codec);
                m_codec = nullptr;
            }
            if (m_muxer) {
                if (m_muxerStarted) AMediaMuxer_stop(m_muxer);
                AMediaMuxer_delete(m_muxer);
                m_muxer = nullptr;
                m_muxerStarted = false;
            }
            if (m_fileDescriptor >= 0) {
                ::close(m_fileDescriptor);
                m_fileDescriptor = -1;
            }
        }

    private:
        geode::Result<> failOpen(const char* reason) {
            close();
            return geode::Err(reason);
        }

        void signalEndOfStream() {
            for (int attempt = 0; attempt < 200; ++attempt) {
                const ssize_t slot = AMediaCodec_dequeueInputBuffer(m_codec, kDequeueTimeoutUs);
                if (slot >= 0) {
                    const int64_t timestampUs = m_frameIndex * 1000000LL / m_fps;
                    AMediaCodec_queueInputBuffer(m_codec, static_cast<size_t>(slot), 0, 0, static_cast<uint64_t>(timestampUs), AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM);
                    break;
                }
                drainEncoded(false);
            }
            for (int attempt = 0; attempt < 500 && !drainEncoded(true); ++attempt) {
            }
        }

        bool drainEncoded(bool waiting) {
            AMediaCodecBufferInfo info;
            for (;;) {
                const ssize_t slot = AMediaCodec_dequeueOutputBuffer(m_codec, &info, waiting ? kDequeueTimeoutUs : 0);
                if (slot == AMEDIACODEC_INFO_TRY_AGAIN_LATER) return false;
                if (slot == AMEDIACODEC_INFO_OUTPUT_FORMAT_CHANGED) {
                    AMediaFormat* output = AMediaCodec_getOutputFormat(m_codec);
                    m_track = AMediaMuxer_addTrack(m_muxer, output);
                    AMediaFormat_delete(output);
                    AMediaMuxer_start(m_muxer);
                    m_muxerStarted = true;
                    continue;
                }
                if (slot < 0) continue;

                if (info.flags & AMEDIACODEC_BUFFER_FLAG_CODEC_CONFIG) info.size = 0;
                if (info.size > 0 && m_muxerStarted) {
                    size_t capacity = 0;
                    uint8_t* encoded = AMediaCodec_getOutputBuffer(m_codec, static_cast<size_t>(slot), &capacity);
                    if (encoded) AMediaMuxer_writeSampleData(m_muxer, static_cast<size_t>(m_track), encoded, &info);
                }
                const bool finished = (info.flags & AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM) != 0;
                AMediaCodec_releaseOutputBuffer(m_codec, static_cast<size_t>(slot), false);
                if (finished) return true;
            }
        }

        void convertRowPairs(const uint8_t* rgba, int firstPair, int lastPair) {
            uint8_t* lumaPlane = m_yuv.data();
            uint8_t* chromaPlane = m_yuv.data() + static_cast<size_t>(m_stride) * m_sliceHeight;
            const size_t rowBytes = static_cast<size_t>(m_width) * 4;

            for (int pair = firstPair; pair < lastPair; ++pair) {
                const int topRow = pair * 2;
                const uint8_t* upper = rgba + static_cast<size_t>(topRow) * rowBytes;
                const uint8_t* lower = upper + rowBytes;
                uint8_t* lumaUpper = lumaPlane + static_cast<size_t>(topRow) * m_stride;
                uint8_t* lumaLower = lumaUpper + m_stride;
                uint8_t* chromaRow = chromaPlane + static_cast<size_t>(pair) * m_stride;

                for (int column = 0; column < m_width; column += 2) {
                    const uint8_t* a = upper + column * 4;
                    const uint8_t* b = a + 4;
                    const uint8_t* c = lower + column * 4;
                    const uint8_t* d = c + 4;

                    lumaUpper[column] = lumaOf(a);
                    lumaUpper[column + 1] = lumaOf(b);
                    lumaLower[column] = lumaOf(c);
                    lumaLower[column + 1] = lumaOf(d);

                    const int red = (a[0] + b[0] + c[0] + d[0]) >> 2;
                    const int green = (a[1] + b[1] + c[1] + d[1]) >> 2;
                    const int blue = (a[2] + b[2] + c[2] + d[2]) >> 2;
                    chromaRow[column] = clampByte(((-38 * red - 74 * green + 112 * blue + 128) >> 8) + 128);
                    chromaRow[column + 1] = clampByte(((112 * red - 94 * green - 18 * blue + 128) >> 8) + 128);
                }
            }
        }

        static uint8_t lumaOf(const uint8_t* pixel) {
            return clampByte(((66 * pixel[0] + 129 * pixel[1] + 25 * pixel[2] + 128) >> 8) + 16);
        }

        void convertToSemiPlanar(const std::vector<uint8_t>& rgba) {
            const int pairs = m_height / 2;
            const int workers = static_cast<int>(std::clamp(std::thread::hardware_concurrency(), 1u, 4u));
            const int chunk = (pairs + workers - 1) / workers;

            std::vector<std::thread> helpers;
            for (int worker = 1; worker < workers; ++worker) {
                const int first = worker * chunk;
                const int last = std::min(pairs, first + chunk);
                if (first >= last) break;
                helpers.emplace_back([this, &rgba, first, last] { convertRowPairs(rgba.data(), first, last); });
            }
            convertRowPairs(rgba.data(), 0, std::min(pairs, chunk));
            for (auto& helper : helpers) helper.join();
        }

        AMediaCodec* m_codec = nullptr;
        AMediaMuxer* m_muxer = nullptr;
        int m_fileDescriptor = -1;
        ssize_t m_track = -1;
        bool m_muxerStarted = false;
        int m_width = 0;
        int m_height = 0;
        int m_fps = 60;
        int m_stride = 0;
        int m_sliceHeight = 0;
        int64_t m_frameIndex = 0;
        std::vector<uint8_t> m_yuv;
    };
}

namespace NXR::Render {
    std::unique_ptr<VideoSink> makeMediaCodecSink() {
        return std::make_unique<MediaCodecSink>();
    }
}
#else
namespace NXR::Render {
    std::unique_ptr<VideoSink> makeMediaCodecSink() {
        return nullptr;
    }
}
#endif
