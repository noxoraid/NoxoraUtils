#include "nxr_render_session.hpp"
#include <eclipse.ffmpeg-api/include/events.hpp>
#include <Geode/binding/FMODAudioEngine.hpp>
#include <Geode/binding/LevelTools.hpp>
#include <Geode/binding/MusicDownloadManager.hpp>
#include <chrono>
#include <cctype>
#include <ctime>
#include <string>
#include "nxr_config.hpp"
#include "nxr_render_keys.hpp"

namespace NXR::Render {
    struct EncoderBinding {
        ffmpeg::events::Recorder recorder;
    };
}

namespace {
    constexpr size_t kMaxPendingFrames = 4;
    constexpr size_t kMaxSpareFrames = 6;

    std::vector<std::string> codecCandidates(int choice) {
#ifdef GEODE_IS_ANDROID
        const std::vector<std::string> hardware { "h264_mediacodec" };
#else
        const std::vector<std::string> hardware { "h264_nvenc", "h264_amf", "h264_videotoolbox" };
#endif
        const std::vector<std::string> software { "libx264", "libopenh264" };

        if (choice == 1) return hardware;
        if (choice == 2) return software;

        std::vector<std::string> combined = hardware;
        combined.insert(combined.end(), software.begin(), software.end());
        return combined;
    }

    std::string safeLevelName() {
        auto* layer = PlayLayer::get();
        if (!layer || !layer->m_level) return "gameplay";

        std::string name = layer->m_level->m_levelName;
        for (char& letter : name) {
            if (!std::isalnum(static_cast<unsigned char>(letter))) letter = '_';
        }
        return name.empty() ? std::string("gameplay") : name;
    }

    std::string timestampLabel() {
        const std::time_t now = std::time(nullptr);
        std::tm local {};
#ifdef _WIN32
        localtime_s(&local, &now);
#else
        localtime_r(&now, &local);
#endif
        char buffer[32];
        std::strftime(buffer, sizeof(buffer), "%Y%m%d_%H%M%S", &local);
        return buffer;
    }

    bool musicAtLevelStart() {
        auto* layer = PlayLayer::get();
        auto* engine = FMODAudioEngine::sharedEngine();
        if (!layer || !layer->m_levelSettings || !engine) return false;

        const int offsetMs = static_cast<int>(layer->m_levelSettings->m_songOffset * 1000.f);
        return engine->getMusicTimeMS(0) <= offsetMs + 400;
    }

    std::filesystem::path levelSongPath() {
        auto* layer = PlayLayer::get();
        if (!layer || !layer->m_level) return {};

        std::filesystem::path path;
        if (layer->m_level->m_songID != 0) {
            path = std::string(MusicDownloadManager::sharedState()->pathForSong(layer->m_level->m_songID));
        } else {
            const std::string fileName = LevelTools::getAudioFileName(layer->m_level->m_audioTrack);
            path = cocos2d::CCFileUtils::sharedFileUtils()->fullPathForFilename(fileName.c_str(), false);
        }

        std::error_code probeError;
        return std::filesystem::is_regular_file(path, probeError) ? path : std::filesystem::path();
    }

    bool mixLevelMusic(const std::filesystem::path& video, const std::filesystem::path& song) {
        const auto mixed = video.parent_path() / (video.stem().string() + "_music.mp4");
        ffmpeg::events::AudioMixer::mixVideoAudio(video.string(), song.string(), mixed.string());

        std::error_code fileError;
        if (!std::filesystem::is_regular_file(mixed, fileError) || std::filesystem::file_size(mixed, fileError) == 0) {
            std::filesystem::remove(mixed, fileError);
            return false;
        }

        std::filesystem::remove(video, fileError);
        std::filesystem::rename(mixed, video, fileError);
        return !fileError;
    }
}

namespace NXR::Render {
    GameplayVideoSession::GameplayVideoSession() = default;

    GameplayVideoSession::~GameplayVideoSession() {
        if (m_finalizeThread.joinable()) m_finalizeThread.join();
        if (m_encodeThread.joinable()) m_encodeThread.join();
    }

    GameplayVideoSession& GameplayVideoSession::get() {
        static GameplayVideoSession instance;
        return instance;
    }

    bool GameplayVideoSession::isAdvancing() const {
        if (!m_active.load(std::memory_order_relaxed)) return false;
        auto* layer = PlayLayer::get();
        return layer && !layer->m_isPaused;
    }

    void GameplayVideoSession::joinFinalizer() {
        if (m_finalizeThread.joinable()) m_finalizeThread.join();
    }

    geode::Result<std::filesystem::path> GameplayVideoSession::begin(const VideoSettings& settings) {
        if (m_active.load()) return geode::Err("Already recording");
        if (m_saving.load()) return geode::Err("Still saving the previous video");
        if (!geode::Loader::get()->isModLoaded(Keys::ffmpegModId)) {
            return geode::Err("Install the FFmpeg API mod (eclipse.ffmpeg-api) first");
        }

        auto* director = cocos2d::CCDirector::sharedDirector();
        auto* view = director ? director->getOpenGLView() : nullptr;
        if (!view) return geode::Err("No render view available");

        const auto frame = view->getFrameSize();
        const int width = static_cast<int>(frame.width) & ~1;
        const int height = static_cast<int>(frame.height) & ~1;
        if (width < 16 || height < 16) return geode::Err("Render size is too small");

        joinFinalizer();

        const auto folder = getFolderRenderPath();
        std::error_code folderError;
        std::filesystem::create_directories(folder, folderError);
        if (folderError) return geode::Err(fmt::format("Cannot create {}", folder.string()));

        const auto outputPath = folder / fmt::format("{}_{}.mp4", safeLevelName(), timestampLabel());

        std::string lastFailure = "No encoder is available";
        std::unique_ptr<EncoderBinding> started;
        for (const auto& codec : codecCandidates(settings.encoderChoice)) {
            auto binding = std::make_unique<EncoderBinding>();

            ffmpeg::RenderSettings render;
            render.m_pixelFormat = ffmpeg::PixelFormat::RGB0;
            render.m_codec = codec;
            render.m_bitrate = settings.bitrateMbps * 1000000;
            render.m_width = width;
            render.m_height = height;
            render.m_fps = settings.fps;
            render.m_outputFile = outputPath.string();

            auto result = binding->recorder.init(render);
            if (result.isOk()) {
                started = std::move(binding);
                break;
            }
            lastFailure = fmt::format("{}: {}", codec, result.unwrapErr());
        }

        if (!started) return geode::Err(lastFailure);

        m_encoder = std::move(started);
        m_settings = settings;
        m_width = width;
        m_height = height;
        m_outputPath = outputPath;
        m_framesQueued = 0;
        m_tailFrames = 0;
        m_tailArmed = false;
        m_pending.clear();
        m_closing = false;
        m_readback.prepare(width, height);
        m_musicPath.clear();
        m_musicSkipNote.clear();
        m_levelRestarted.store(false);
        if (NXRConfig::get().get<bool>(Keys::addMusic, true)) {
            if (!musicAtLevelStart()) m_musicSkipNote = "Music skipped: recording did not start at the beginning of the level";
            else m_musicPath = levelSongPath();
            if (m_musicPath.empty() && m_musicSkipNote.empty()) m_musicSkipNote = "Music skipped: song file not found";
        }
        m_encodeThread = std::thread([this] { encodeLoop(); });
        m_active.store(true);
        return geode::Ok(outputPath);
    }

    void GameplayVideoSession::noteLevelRestart() {
        if (m_active.load()) m_levelRestarted.store(true);
    }

    void GameplayVideoSession::armTail(int frames) {
        m_tailFrames = std::max(frames, 1);
        m_tailArmed = true;
    }

    void GameplayVideoSession::captureFromBackBuffer() {
        if (!isAdvancing()) return;

        auto pixels = takeSpareBuffer();
        if (!m_readback.capture(pixels)) {
            recycle(std::move(pixels));
            return;
        }

        enqueue(std::move(pixels));
        ++m_framesQueued;

        if (!m_tailArmed) return;
        if (--m_tailFrames > 0) return;
        finish();
    }

    void GameplayVideoSession::finish() {
        if (!m_active.exchange(false)) return;

        auto lastFrame = takeSpareBuffer();
        if (m_readback.drain(lastFrame)) {
            enqueue(std::move(lastFrame));
            ++m_framesQueued;
        } else {
            recycle(std::move(lastFrame));
        }
        m_readback.release();

        m_saving.store(true);
        const auto savedPath = m_outputPath;
        const auto savedFrames = m_framesQueued;
        auto songPath = m_musicPath;
        std::string musicNote = m_musicSkipNote;
        if (!songPath.empty() && m_levelRestarted.load()) {
            songPath.clear();
            musicNote = "Music skipped: the level was restarted while recording";
        }

        m_finalizeThread = std::thread([this, savedPath, savedFrames, songPath, musicNote]() mutable {
            {
                std::lock_guard lock(m_queueMutex);
                m_closing = true;
            }
            m_frameReady.notify_all();
            m_spaceFreed.notify_all();

            if (m_encodeThread.joinable()) m_encodeThread.join();
            m_encoder->recorder.stop();
            m_encoder.reset();

            if (savedFrames > 0 && !songPath.empty() && !mixLevelMusic(savedPath, songPath)) {
                musicNote = "Music could not be added";
            }
            m_saving.store(false);

            geode::queueInMainThread([savedPath, savedFrames, musicNote] {
                if (savedFrames == 0) {
                    geode::Notification::create("Nothing was recorded", geode::NotificationIcon::Warning)->show();
                    return;
                }
                const auto message = musicNote.empty()
                    ? fmt::format("Saved {}", savedPath.filename().string())
                    : fmt::format("Saved {} ({})", savedPath.filename().string(), musicNote);
                geode::Notification::create(message, musicNote.empty() ? geode::NotificationIcon::Success : geode::NotificationIcon::Warning)->show();
            });
        });
    }

    void GameplayVideoSession::encodeLoop() {
        for (;;) {
            std::vector<uint8_t> frame;
            {
                std::unique_lock lock(m_queueMutex);
                m_frameReady.wait(lock, [this] { return !m_pending.empty() || m_closing; });
                if (m_pending.empty()) return;
                frame = std::move(m_pending.front());
                m_pending.pop_front();
            }
            m_spaceFreed.notify_one();

            flipRows(frame);
            m_encoder->recorder.writeFrame(frame);
            recycle(std::move(frame));
        }
    }

    void GameplayVideoSession::flipRows(std::vector<uint8_t>& pixels) const {
        const size_t stride = static_cast<size_t>(m_width) * 4;
        for (int top = 0, bottom = m_height - 1; top < bottom; ++top, --bottom) {
            uint8_t* upper = pixels.data() + static_cast<size_t>(top) * stride;
            uint8_t* lower = pixels.data() + static_cast<size_t>(bottom) * stride;
            std::swap_ranges(upper, upper + stride, lower);
        }
    }

    void GameplayVideoSession::enqueue(std::vector<uint8_t>&& pixels) {
        std::unique_lock lock(m_queueMutex);
        m_spaceFreed.wait(lock, [this] { return m_pending.size() < kMaxPendingFrames || m_closing; });
        m_pending.push_back(std::move(pixels));
        lock.unlock();
        m_frameReady.notify_one();
    }

    void GameplayVideoSession::recycle(std::vector<uint8_t>&& pixels) {
        std::lock_guard lock(m_spareMutex);
        if (m_spare.size() < kMaxSpareFrames) m_spare.push_back(std::move(pixels));
    }

    std::vector<uint8_t> GameplayVideoSession::takeSpareBuffer() {
        std::vector<uint8_t> buffer;
        {
            std::lock_guard lock(m_spareMutex);
            if (!m_spare.empty()) {
                buffer = std::move(m_spare.back());
                m_spare.pop_back();
            }
        }
        buffer.resize(static_cast<size_t>(m_width) * static_cast<size_t>(m_height) * 4);
        return buffer;
    }
}
