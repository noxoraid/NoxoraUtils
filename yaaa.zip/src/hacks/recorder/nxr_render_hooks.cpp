#include <Geode/Geode.hpp>
#include <Geode/modify/CCDirector.hpp>
#include <Geode/modify/CCEGLView.hpp>
#include <Geode/modify/CCScheduler.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include "../../core/nxr_config.hpp"
#include "../../core/nxr_gui.hpp"
#include "../../core/nxr_render_keys.hpp"
#include "../../core/nxr_render_session.hpp"
#include "../../interface/cocos/nxr_overlay_button.hpp"

namespace {
    bool g_buttonHidden = false;
    bool g_buttonWasVisible = true;

    bool recorderHackEnabled(const char* name) {
        return NXR::Gui::get().getWindow(NXR::Render::Keys::window).findHackByName(name).getEnabled();
    }

    void applyButtonVisibility(bool shouldHide) {
        auto* button = NXROverlayButton::instance;
        if (!button) return;

        if (shouldHide && !g_buttonHidden) {
            g_buttonWasVisible = button->isVisible();
            g_buttonHidden = true;
            button->setVisible(false);
            return;
        }

        if (!shouldHide && g_buttonHidden) {
            g_buttonHidden = false;
            button->setVisible(g_buttonWasVisible);
        }
    }
}

class $modify(NXRRenderStepScheduler, cocos2d::CCScheduler) {
    void update(float dt) {
        auto& session = NXR::Render::GameplayVideoSession::get();
        if (session.isAdvancing()) dt = session.stepSeconds();
        CCScheduler::update(dt);
    }
};

class $modify(NXRRenderSwapView, cocos2d::CCEGLView) {
    void swapBuffers() {
        NXR::Render::GameplayVideoSession::get().captureFromBackBuffer();
        CCEGLView::swapBuffers();
    }
};

class $modify(NXRRenderDirector, cocos2d::CCDirector) {
    void drawScene() {
        auto& session = NXR::Render::GameplayVideoSession::get();
        const bool hideButton = session.isAdvancing() && recorderHackEnabled(NXR::Render::Keys::hideButtonHack);
        applyButtonVisibility(hideButton);
        CCDirector::drawScene();
    }
};

class $modify(NXRRenderPlayLayer, PlayLayer) {
    void levelComplete() {
        PlayLayer::levelComplete();

        auto& session = NXR::Render::GameplayVideoSession::get();
        if (!session.isActive()) return;
        if (!recorderHackEnabled(NXR::Render::Keys::autoStopHack)) return;

        const int tailSeconds = std::clamp(NXRConfig::get().get<int>(NXR::Render::Keys::tailSeconds, 3), 0, 30);
        session.armTail(tailSeconds * session.frameRate());
    }

    void resetLevel() {
        PlayLayer::resetLevel();
        NXR::Render::GameplayVideoSession::get().noteLevelRestart();
    }

    void onQuit() {
        NXR::Render::GameplayVideoSession::get().finish();
        PlayLayer::onQuit();
    }
};
